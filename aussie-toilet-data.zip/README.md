This visualization is covers the domain task "What parts of
Australia have an influx of public toilets?"

The visualization is currently not working. The goal is to
be able to view sub-categories of Australia by clicking on
the map to get more details.

I want you to be able to look at the states an towns in
those states, and see where there are more toilets vs. fewer
toilets. Right now the color scheme doesn't quite work with
the data, so this actually doesn't do anything more than a
map.
